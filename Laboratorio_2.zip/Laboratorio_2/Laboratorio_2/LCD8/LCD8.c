/*
 * LCD8.c
 *
 * Created: 30/01/2025 19:15:46
 *  Author: amola
 */ 

#include "LCD8.h"


//inicializamos pins del lcd
void initLCD8(){
	DDRD |= (1<<2)|(1<<3)|(1<<4)|(1<<5)|(1<<6)|(1<<7);
	PORTD = 0; 
	DDRB |= (1<<0)|(1<<1)|(1<<5);
	PORTB &= ~(1<<PORTB5);
	PORTB &= ~(1<<PORTB0);
	PORTB &= ~(1<<PORTB1);

	DDRC |= (1<<PORTC0);
	PORTC &= ~(1<<PORTC0);


	LCDport(0x00);
	_delay_ms(20);
	LCDcomando(0x38);
	LCDcomando(0x0C);
	LCDcomando(0x06);
	LCDcomando(0x01);

}

//Funcion para mandar comanndo 
void LCDcomando(char a){
	//RS = 0
	PORTC &= ~(1<<PORTC0);
	LCDport(a);
	//enable 1
	PORTB |= (1<<PORTB5);
	_delay_ms(4);
	PORTB &= ~(1<<PORTB5);
}

//funcion  para colocar  un  valor  en el puerto
void  LCDport(char a){
	if (a & 1)
	PORTD |=  (1<<PORTD7);
	else
	PORTD &= ~(1<<PORTD7);
	
	if (a & 2)
	PORTD |=  (1<<PORTD6);
	else
	PORTD &= ~(1<<PORTD6);
	
	if (a & 4)
	PORTD |=  (1<<PORTD5);
	else
	PORTD &= ~(1<<PORTD5);
	
	if (a & 8)
	PORTD |=  (1<<PORTD4);
	else
	PORTD &= ~(1<<PORTD4);
	
	if (a & 16)
	PORTB |=  (1<<PORTB0);
	else
	PORTB&= ~(1<<PORTB0);
	
	if (a & 32)
	PORTB|=  (1<<PORTB1);
	else
	PORTB &= ~(1<<PORTB1);
	
	if (a & 64)
	PORTD |=  (1<<PORTD2);
	else
	PORTD &= ~(1<<PORTD2);
	
	if (a & 128)
	PORTD |=  (1<<PORTD3);
	else
	PORTD &= ~(1<<PORTD3);
}

//funcion para mandar un caracter
void LCDcaracter(char c){
	//rs en 1
	PORTC |= (1<<PORTC0);
	LCDport(c);
	_delay_ms(4);
	//en 1
	PORTB |= (1<<PORTB5);
	_delay_ms(4);
	PORTB &= ~(1<<PORTB5);

}

void LCDcadena(char *a){
	int i;
	for (i = 0; a[i] != '\0'; i++)
	LCDcadena(a[i]);
}

void LCDderecha(void){
	LCDcomando(0x1C);
}

void LCDizquierda(void){
	LCDcomando(0x18);
}

void LCDcursor(char c, char f){
	char temp;
	if (f == 1){
		temp = 0x80 + c - 1;
		LCDcomando(temp);
		} else if (f == 2){
		temp = 0xC0 + c - 1;
		LCDcomando(temp);
	}
}
