/*
 * LCD8.h
 *
 * Created: 30/01/2025 19:15:30
 *  Author: amola
 */ 


#ifndef LCD8_H_
#define LCD8_H_
#define F_CPU 16000000
#include <avr/delay.h>
#include <avr/io.h>

#define E  (1 << PORTB5)
//Funcion para inicializar el  lcd en   modo de  8 bits
void initLCD8(void);
//funcion para  colocar un  valo en el puerto
void LCDport(char a);
//funcion para mandar un  comando  
void  LCDcomando(char a);
//funcion para mandar un   caracter
void LCDcaracter(char c);
//funcion para mandar  una cadena
void  LCDcadena(char *a); //uso de punteros 
//desplazamiento hacia la derecha
void LCDderecha(void);
//desplazamiento hacia la izquierda 
void LCDizquierda(void);
//establecer  el cursor
void LCDcursor(char c, char f);





#endif /* LCD8_H_ */