/*
 * Laboratorio_2.c
 *
 * Created: 30/01/2025 19:09:08
 * Author : amola
 */ 


#define F_CPU 16000000
#include <avr/delay.h>
#include <avr/io.h>

#include "ADC/ADC.h"
#include "UART/UART.h"
#include "LCD8/LCD8.h"

volatile uint16_t sensor1 = 0;
volatile uint16_t sensor2 = 0;
volatile int sensor3 = 0;



ISR(USART_RX_vect) {
	char received = UART_receive();
	if (received == '+') sensor3++;
	if (received == '-') sensor3--;
}

int main() {
	ADC_init(1);
	UART_init(9600);
	initLCD8();
	ADC_startConversion(0);
	
	sei();

	while (1) {
		char buffer[16];
		LCDcursor(1, 1);
		sprintf(buffer, "S1: %4d", sensor1);
		LCDcadena(buffer);
		
		LCDcursor(2, 1);
		sprintf(buffer, "S2: %4d", sensor2);
		LCDcadena(buffer);
		
		LCDcursor(3, 1);
		sprintf(buffer, "S3: %4d", sensor3);
		LCDcadena(buffer);
		
		_delay_ms(500);
	}
}


