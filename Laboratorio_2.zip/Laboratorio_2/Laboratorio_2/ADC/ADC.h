/*
 * ADC.h
 *
 * Created: 6/02/2025 09:33:11
 *  Author: amola
 */ 


// adc_lib.h
#ifndef ADC_H_
#define ADC_H_

#include <avr/io.h>
#include <avr/interrupt.h>

// Definici�n de referencias de voltaje
typedef enum {
	ADC_REF_AREF = 0,
	ADC_REF_AVCC = (1 << REFS0),
	ADC_REF_INTERNAL_1V1 = (1 << REFS1) | (1 << REFS0)
} ADC_Reference;

// Prototipos de funciones
void ADC_init(uint8_t ref);
void ADC_startConversion(uint8_t channel);
uint16_t ADC_getResult(void);

#endif // ADC_LIB_H