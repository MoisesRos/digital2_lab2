/*
 * ADC.c
 *
 * Created: 6/02/2025 09:33:26
 *  Author: amola
 */ 
#include "ADC.h"

volatile uint16_t adc_result[2];  // Array para almacenar los valores de los sensores
volatile uint8_t current_channel = 0;



void ADC_init(ADC_Reference ref) {
	// Configurar la referencia de voltaje
	ADMUX = ref;  // Configurar referencia de voltaje	
	// Habilitar el ADC, activar interrupciones y configurar prescaler en 128 (16MHz / 128 = 125kHz)
	ADCSRA = (1 << ADEN) | (1 << ADIE) | (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);
	
	// Habilitar interrupciones globales
	sei();
}

void ADC_startConversion(uint8_t channel) {
	// Limpiar los bits del canal y configurarlo
	ADMUX = (ADMUX & 0xF0) | (channel & 0x0F);
	
	// Iniciar conversi�n
	ADCSRA |= (1 << ADSC);
}

uint16_t ADC_getResult(void) {
	return adc_result;
}

ISR(ADC_vect) {
	adc_result[current_channel] = ADC;  // Guardar lectura
	current_channel = !current_channel;  // Alternar entre canal 0 y canal 1
	ADC_startConversion(current_channel);  // Iniciar siguiente conversi�n
}