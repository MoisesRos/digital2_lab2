/*
 * UART.h
 *
 * Created: 6/02/2025 09:38:56
 *  Author: amola
 */ 


#ifndef UART_H_
#define UART_H_

#include <avr/io.h>

void UART_init(uint16_t baudrate);
void UART_transmit(char data);
char UART_receive(void);
void UART_transmitString(const char *str);

#endif // UART_H