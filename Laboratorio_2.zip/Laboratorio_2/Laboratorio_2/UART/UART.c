/*
 * UART.c
 *
 * Created: 6/02/2025 09:39:14
 *  Author: amola
 */ 
#define F_CPU 16000000
#include <avr/delay.h>
#include "UART.h"

void UART_init(uint16_t baudrate) {
	uint16_t ubrr = F_CPU/16/baudrate - 1;
	UBRR0H = (ubrr >> 8);
	UBRR0L = ubrr;
	UCSR0B = (1 << TXEN0) | (1 << RXEN0); // Habilitar TX y RX
	UCSR0C = (1 << UCSZ01) | (1 << UCSZ00); // Modo 8 bits, sin paridad, 1 bit de stop
}

void UART_transmit(char data) {
	while (!(UCSR0A & (1 << UDRE0))); // Esperar a que el buffer est� vac�o
	UDR0 = data;
}

char UART_receive(void) {
	while (!(UCSR0A & (1 << RXC0))); // Esperar a recibir un dato
	return UDR0;
}

void UART_transmitString(const char *str) {
	while (*str) {
		UART_transmit(*str++);
	}
}
